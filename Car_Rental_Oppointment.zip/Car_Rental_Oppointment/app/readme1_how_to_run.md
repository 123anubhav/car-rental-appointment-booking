## PART I :- How to Run this Project :-

Step 1 --> Install MongoDB Compass
Step 2 --> Go to the path -> "appointment-booking\api" and run --> npm i
       --> Then run --> npm start
Step 3 --> Go to the path -> "appointment-booking\app" and run --> npm i 
       --> Then run --> npm start

Now the app will start running on port --> http://localhost:4200/

Step 4 --> Go to the browser and enter --> http://localhost:4200/ (The Application will start)
.........................................................................................
........................................................................................

## PART 2 :- HOW TO USE THE APPLICATION 

Step 1 :- Book the appointment.
-------> Add three Fields (Date, Name, email).

Step 2 :- Click on Make Appointment (And your Appointment will be Scheduled).

--> (The corresponding data will be stored in MongoDB.)
.........................................................................................
........................................................................................

## PART 3 :- HOW TO WATCH THE ALREADY BOOKED APPOINTMENT

Step 1 :- On the browser enter --> http://localhost:4200/appointment-list
 --------------> All the booking will be displayed here.

.........................................................................................
........................................................................................

## PART 4 :- HOW TO CANCEL/DELETE THE ALREADY BOOKED APPOINTMENT

Step 1 :- On the browser enter --> http://localhost:4200/appointment-list

Step 2 :- Click on --> "Cancel button" (Your booking will be canceled)

.........................................................................................
........................................................................................
--Anubhav